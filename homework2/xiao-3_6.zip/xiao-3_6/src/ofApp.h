#pragma once

#include "ofMain.h"

class ofApp : public ofBaseApp
{
public:
    void setup();
    void update();
    void draw();
    
    void moveCircle(int i, float x, float y);
    
    float distance(float x1, float y1, float x2, float y2);
    
    ofColor getColor(float x, float y);
    
private:
    const int NUM_CIRCLES = 3;
    const float RADIUS = 50.0f;
    
    ofVec2f circlePositions[3];
    ofColor circleColors[3];
};
