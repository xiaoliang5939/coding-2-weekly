#include "ofApp.h"

void ofApp::setup()
{
    ofSetBackgroundColor(255);
    
    // Randomly initialize the positions and colors of the three circles
    for (int i = 0; i < NUM_CIRCLES; i++) {
        float x = ofRandom(RADIUS, ofGetWidth() - RADIUS);
        float y = ofRandom(RADIUS, ofGetHeight() - RADIUS);
        circlePositions[i] = ofVec2f(x, y);
        circleColors[i] = ofColor(ofRandom(255), ofRandom(255), ofRandom(255));
        
    }
}

void ofApp::update()
{
    // 检查圆形之间是否相交 Check if circles intersect
    for (int i = 0; i < NUM_CIRCLES; i++) {
        for (int j = i + 1; j < NUM_CIRCLES; j++) {
            float dist = distance(circlePositions[i].x, circlePositions[i].y, circlePositions[j].x, circlePositions[j].y);
            if (dist < RADIUS * 2) {
                // 如果圆形相交，则将第二个圆形移动到离第一个圆形最远的位置
                float angle = atan2(circlePositions[j].y - circlePositions[i].y, circlePositions[j].x - circlePositions[i].x);
                float dx = (RADIUS * 6 - dist) / 6 * cos(angle);
                float dy = (RADIUS * 2 - dist) / 2 * sin(angle);
                moveCircle(j, circlePositions[j].x + dx, circlePositions[j].y + dy);
            }
        }
    }
    
    // 移动圆形 Moving circle
    for (int i = 0; i < NUM_CIRCLES; i++) {
        moveCircle(i, ofGetMouseX(), ofGetMouseY());
    }
}

void ofApp::draw()
{
    // 画圆形 Draw a circle
    for (int i = 0; i < NUM_CIRCLES; i++) {
        ofSetColor(circleColors[i]);
        ofDrawCircle(circlePositions[i], RADIUS);
    }
}

void ofApp::moveCircle(int i, float x, float y)
{
    // 移动圆形并确保不会移动到窗口外面 Move the circle and make sure it does not move outside the window
    circlePositions[i].x = ofClamp(x, RADIUS, ofGetWidth() - RADIUS);
    circlePositions[i].y = ofClamp(y, RADIUS, ofGetHeight() - RADIUS);
    
    // 计算圆形颜色 Computed circular color
    circleColors[i] = getColor(circlePositions[i].x, circlePositions[i].y);
}

float ofApp::distance(float x1, float y1, float x2, float y2)
{
    // 计算两个点之间的距离 Calculate the distance between two points
    return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
}

ofColor ofApp::getColor(float x, float y)
{
    // 根据圆形的位置计算颜色 Calculate the color based on the position of the circle
    float r = ofMap(x, RADIUS, ofGetWidth() - RADIUS, 0, 255);
    float g = ofMap(y, RADIUS, ofGetHeight() - RADIUS, 0, 255);
    float b = ofMap(distance(x, y, ofGetWidth() / 2, ofGetHeight() / 2), 0, ofGetWidth() / 2, 255, 0);
    return ofColor(r, g, b);
}
