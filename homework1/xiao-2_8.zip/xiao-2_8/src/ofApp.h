#pragma once

#include "ofMain.h"

class ofApp : public ofBaseApp {
public:
    void setup();
    void update();
    void draw();
    
private:
    float amplitude1, amplitude2, amplitude3;
    float wavelength1, wavelength2, wavelength3;
    float frequency1, frequency2, frequency3;
    float phase1, phase2, phase3;
    ofColor color1, color2, color3;
};
