#include "ofApp.h"

void ofApp::setup() {
    ofBackground(0);
    ofSetFrameRate(60);
    ofEnableSmoothing();
    
    amplitude1 = 40;
    amplitude2 = 60;
    amplitude3 = 80;
    
    wavelength1 = 200;
    wavelength2 = 300;
    wavelength3 = 400;
    
    frequency1 = 1.0 / wavelength1;
    frequency2 = 1.0 / wavelength2;
    frequency3 = 1.0 / wavelength3;
    
    phase1 = 0;
    phase2 = 0;
    phase3 = 0;
    
    color1 = ofColor(255, 0, 0);
    color2 = ofColor(0, 255, 0);
    color3 = ofColor(0, 0, 255);
}

void ofApp::update() {
    int mouseX = ofGetMouseX();
    int mouseY = ofGetMouseY();
    
    float mappedMouseX = ofMap(mouseX, 0, ofGetWidth(), 0, 2 * PI);
    float mappedMouseY = ofMap(mouseY, 0, ofGetHeight(), 0, 2 * PI);
    
    amplitude1 = ofMap(mappedMouseX, 0, 2 * PI, 20, 60);
    amplitude2 = ofMap(mappedMouseY, 0, 2 * PI, 30, 90);
    amplitude3 = ofMap(mappedMouseX + mappedMouseY, 0, 4 * PI, 40, 120);
    
    phase1 += frequency1;
    phase2 += frequency2;
    phase3 += frequency3;
}

void ofApp::draw() {
    ofPushMatrix();
    ofTranslate(0, ofGetHeight() / 2);
    
    ofSetColor(color1);
    ofBeginShape();
    for (int x = 0; x < ofGetWidth(); x += 5) {
        float y = amplitude1 * sin(frequency1 * x + phase1);
        ofVertex(x, y);
    }
    ofEndShape(false);
    
    ofSetColor(color2);
    ofBeginShape();
    for (int x = 0; x < ofGetWidth(); x += 5) {
        float y = amplitude2 * sin(frequency2 * x + phase2);
        ofVertex(x, y);
    }
    ofEndShape(false);
    
    ofSetColor(color3);
    ofBeginShape();
    for (int x = 0; x < ofGetWidth(); x += 5) {
             float y = amplitude3 * sin(frequency3 * x + phase3);
             ofVertex(x, y);
         }
         ofEndShape(false);
         
         ofPopMatrix();
     }
